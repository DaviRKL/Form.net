﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Validacao_Form.Models;

namespace FormIHC1.Data
{
    public class FormIHC1Context : DbContext
    {
        public FormIHC1Context (DbContextOptions<FormIHC1Context> options)
            : base(options)
        {
        }

        public DbSet<Validacao_Form.Models.Denuncia> Denuncia { get; set; } = default!;
    }
}
